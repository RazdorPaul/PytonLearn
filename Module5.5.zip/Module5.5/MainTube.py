import UrTube

"""
Точка входа в программу, основной рабочий скрипт, через который 
идет доступ к классам UrTube, Users, Videos. Тут прописана логика работы
страницы сайта с видео
"""

def readUsers(_users):
    #Функция считывает файл с данными всех зарегистрированных
    #пользователей и на основе этого файла строит словарь
    #с данными каждого пользователя. Ключ в словаре-имя пользователя,
    # значение-список из хеша пароля и возраста
    user_dict = {}
    str_buff = ''
    try:
        users = open(_users, 'r', encoding="utf8")
        str_buff = users.readlines()
    except Exception:
        users = open(_users, 'a', encoding="utf8")
    users.close()
    if len(str_buff) != 0:
        for i in range(len(str_buff)):
            buff = str_buff[i].split()
            user_dict.update({buff[0]: [buff[1], int(buff[2])]})
    return user_dict

def readVideos(_videos):
    #Функция считывает файл с данными видео
    #и на основе этого файла строит словарь. Ключ в словаре-название видео,
    # значение-список из длительности и возрастного ограничения
    str_buff = ''
    user_video = {}
    try:
        video = open(_videos, 'r', encoding="utf8")
        str_buff = video.readlines()
    except Exception:
        video = open(_videos, 'a', encoding="utf8")
    video.close()
    if len(str_buff) != 0:
        for i in range(len(str_buff)):
            video_buf = str_buff[i].split()
            value = [int(video_buf.pop(0)), int(video_buf.pop(0))]
            str_ = ''
            for j in range(len(video_buf)):
                str_ = str_ + video_buf[j] + ' '
            str_ = str_.rstrip()
            user_video.update({str_: value})
    return user_video


ur = UrTube.UrTube(readUsers("users.txt"), readVideos("videos.txt"))

while True:
    #Тут прописана логика взаимодействия с главным классом UrTube
    if ur.current_user != None:
        print("\nДобро пожаловать,", ur.current_user.nick)
    print("Вы находитесь в программе просмотра видеороликов"
          "\nЧто вы хотите сделать?"
          "\n\t1. Войти в аккаунт"
          "\n\t2. Зарегистрироваться"
          "\n\t3. Найти видео"
          "\n\t4. Выбрать видео для просмотра"
          "\n\t5. Добавить видео"
          "\n\t6. Выйти из аккаунта"
          "\n\t7. Выйти из программы")
    flag = input()
    if flag == '1':
        ur.log_in()
    elif flag == '2':
        ur.registration()
    elif flag == '3':
        list_videos = ur.searchVideo(input("Какое видео хотите найти? "))
        if len(list_videos) == 0:
            print("Такое видео не найдено")
        else:
            print(f"По вашему запросу найдено {len(list_videos)} видео")
            for i in range(len(list_videos)):
                print(list_videos[i])
    elif flag == '4':
        ur.choiceVideo()
    elif flag == '5':
        ur.addVideo()
    elif flag == '6':
        ur.log_out()
    elif flag == '7':
        break
    else:
        print("\nНепонятно, что вы хотите. Повторите выбор\n")

