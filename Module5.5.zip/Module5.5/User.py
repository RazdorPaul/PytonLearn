class User:
    """
    Класс описывает объект пользователя, содержит атрибуты-
    имя пользователя, его возраст, и пароль
    """

     def __init__(self, nick_, pass_, age_ = 0):
         self.nick = nick_
         self.password = pass_
         self.age = int(age_)

     def getName(self):
         #Возвращает имя пользователя
         return self.nick

     def getPass(self):
         #Возвращает пароль в виде хеша
         return self.password

     def checkPass(self, pass_):
         #Проверка пароля. Возвращает True Если введенный пароль совпадает с зарегистриролванным
         flag = True
         if pass_ != self.password:
             flag = False
         return flag

     def getAge(self):
         #Возвращает возраст пользоввателя
         return self.age