import User
import Videos
import time
import hashlib


class UrTube:
    """
    Основной класс программы, содержащий базу пользователей(передается конструктору словарь как параметр),
    база видео(передается конструктору как параметр
    На основе переданных словарей строится список объектов User и Video
    """

    def __init__(self, _users, _videos):
        """
        :param _users:
        словарь-база пользователей
        :param _videos:
        словарь, база видеофалов
        """
        self.users = []             #Список объектов User
        self.current_user = None    #Содержит Объект User в качестве текущего пользователя
        self.videos = []            #Список объектов Videos
        #Далее заполнение списков пользователе и видеофайлов
        for key in _users:
            user = User.User(key, _users.get(key)[0], _users.get(key)[1])
            self.users.append(user)
        for key in _videos:
            video = Videos.Videos(key, _videos.get(key)[0], _videos.get(key)[1])
            self.videos.append(video)

    def playVideo(self, video):
        #Функция имитирует воспроизведение видео
        print(f"Воспроизведение видео {video.getTitle()}")
        while video.curr_time <= video.getDuration():
            dur = video.curr_time
            h = dur // 3600
            dur %= 3600
            m = dur // 60
            s = dur % 60
            print(f"Время воспроизведения {h}:{m}:{s}", end='\r')
            time.sleep(1)
            video.curr_time += 1
        print("\nКонец Воспроизведения", end='\n')

    def addVideo(self):
        #Функция добавляет новый видеофайл в базу
        #Если такое название в базе есть, выводится сообщение об этом
        name = input("Введите название: ")
        for i in range(len(self.videos)):
            if name.lower() == self.videos[i].getTitle().lower():
                print("Видео с таким названием уже существует!")
                break
        duration = input("Введите длительность видео в секундах: ")
        adult = int(input("Введите возрастное ограничение: "))
        video = open("videos.txt", 'a', encoding="utf8")
        video.write(str(duration) + ' ' + str(adult) + ' ' + name + '\n')
        video.close()
        video = Videos.Videos(name, duration, adult)
        self.videos.append(video)

    def crypt_pass(self, word):
        #Функция хеширует введенный при регистрации\авторизации пароль
        hash_ = hashlib.md5(b'{word}')
        pass_ = hash_.hexdigest()
        return pass_

    def choiceVideo(self):
        # Функция поиска и выбора видеофайла
        # Поиск видео по точным совпадениям введенного пользователем
        # в зарегистрированных в базе наименованиях
        # Если совпадений больше одного- выводится список найденных видео
        # если совпадений нет- выводится сообщение об этом
        name = input("Какое видео хотите посмотреть? Введите название: ")
        name = self.searchVideo(name)
        if len(name) == 0:
            print("Такое видео отсутствует")
        elif len(name) == 1:
            video = name[0]
            for i in range(len(self.videos)):
                if video == self.videos[i].getTitle().lower():
                    video = self.videos[i]
                    break
            #В этом блоке проверяется аторизация и
            #проверка возраста пользователя для воспроизведения
            if self.current_user == None:
                print("Для просмотра вам необходимо войти в систему")
            elif video.checkAdult(self.current_user.getAge()) == False:
                print("Вы еще слишком малы для просмотра этого видео")
            else:
                self.playVideo(video)
        else:
            print(f"По вашему запросу найдено {len(name)} видео")
            for i in range(len(list_videos)):
                print(list_videos[i])
            self.choiceVideo()

    def registration(self):
        #Функция регистрации нового пользователя и
        #запись в файл данных нового пользователя
        #После регистрации новый пользователь автоматически авторизуется
        name = input("Введите ваш логин: ")
        for i in range(len(self.users)):
            if name.lower() == self.users[i].getName().lower():
                print("Такой логин уже существует!")
                self.registration()
                break
        pass_ = self.crypt_pass(input("Ведите пароль: "))
        age = int(input("Введите ваш возраст: "))
        user = open("users.txt", 'a', encoding="utf8")
        user.write(name + ' ' + str(pass_) + ' ' + str(age) + '\n')
        user.close()
        self.current_user = User.User(name, pass_, age)
        self.users.append(self.current_user)

    def log_in(self):
        #Функция авторизации пользователя
        #Если пользователь с таким логином не найден-предложение пройти регистрацию.
        user = User.User(input("Введите логин: "), self.crypt_pass(input("Введите пароль: ")))
        flag = False
        for i in range(len(self.users)):
            if user.getName().lower() == self.users[i].getName().lower() and self.users:
                flag = True
                self.current_user = self.users[i]
                break
        if flag == False:
            key = input("Пользователь с таким именем не найден, хотите зарегистрироваться y/n? ")
            if key == 'y':
                self.registration()
            else:
                return
        else:
            if self.current_user.checkPass(user.getPass()) == False:
                print("Неверное имя пользователя или пароль!")

    def log_out(self):
        #Функция сброса текущего пользователя
        self.current_user = None
        print("Вы вышли из вашей учетной записи")
        return

    def searchVideo(self, name):
        #Функция реализует поиск видео
        #Веденное пользователем имя ищется в названиях из базы видео
        #Если вхождений пользовательского запроса несколько-формируется список
        #из найденных названий. Поиск идет без учета регистра
        name = name.lower()
        buff = []
        for i in range(len(self.videos)):
            name_video = self.videos[i].getTitle().lower()
            if name_video.find(name) != -1:
                buff.append(name_video)
        return buff


