class Videos:
    """
    Класс описывает объект Videos
    атрибуты Возрастное ограничение, текущая секунда
    длительность видеофайла и его название
    """
    def __init__(self, title_, dur, adult_):
        self.title = title_
        self.duration = dur;
        self.curr_time = 0
        self.adult = adult_

    def getTitle(self):
        #Возвращает наименование видео
        return self.title

    def getDuration(self):
        #Возвращает длительность видеофайла
        return self.duration

    def checkAdult(self, adult_):
        #Проверка возраста пользователя для воспроизведения
        #Если возраст пользователя меньше возрастного ограничения
        #Возвращается False
        flag = False
        if adult_ >= self.adult:
            flag = True
        return flag
